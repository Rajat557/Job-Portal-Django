from django.shortcuts import render,get_object_or_404,redirect
from django.http import HttpResponseRedirect
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, logout, authenticate
from django.contrib import messages
from django.views.decorators.cache import cache_control
from .models import *
from django.core.mail import send_mail
from datetime import datetime, timedelta
from django.conf import settings

# Create your views here.

def home(request):
    feeds = Feedback.objects.all()
    jobs = list(Job_Post.objects.all())
    today = datetime.now().strftime("%Y-%m-%d")
    today = datetime.date(datetime.strptime(today, "%Y-%m-%d"))
    # print(type(today))
    # print((int(str(today)[8:])%30))
    # print(int(str(jobs[1].upto)[8:])%30)
    for i in jobs:
        # if abs((int(str(today)[8:])%30) - (int(str(i.upto)[8:])%30)) >= 5:
        if today - i.upto >= timedelta(5): 
            print(i.post)
            i.delete()

    # print(today)
    if request.method == 'POST':
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        mobile = request.POST.get('mobile')
        email = request.POST.get('email')
        password = request.POST.get('password')


        if len(password) < 8:
            messages.error(request, 'Password must be 8 character long.')
            return HttpResponseRedirect('/')

        if not any(x.isdigit() for x in password):
            messages.error(request, 'Password must contain at least one digit.')
            return HttpResponseRedirect('/')

        if not any(x.islower() for x in password):
            messages.error(request, 'Password must contain at least one small letter.')
            return HttpResponseRedirect('/')

        if not any(x.isupper() for x in password):
            messages.error(request, 'Password must contain at least one capital letter.')
            return HttpResponseRedirect('/')

        else:
            usr = User.objects.create_user(username=email, email=email, password=password)
            usr.first_name = fname
            usr.last_name = lname
            usr.save()

            user = Job_Seeker(user=usr, phone=mobile)
            user.save()
            messages.success(request, 'Candidate Registered successfully.')
            return HttpResponseRedirect('/')


    return render(request, 'home.html', {'jobs' : jobs, 'feedbacks' : feeds, 'today' : today})


def registerRecruiter(request):
    if request.method == 'POST':
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        cname = request.POST.get('cname')
        mobile = request.POST.get('mobile')
        email = request.POST.get('email')
        password = request.POST.get('password')


        if len(password) < 8:
            messages.error(request, 'Password must be 8 character long.')
            return HttpResponseRedirect('/')

        if not any(x.isdigit() for x in password):
            messages.error(request, 'Password must contain at least one digit.')
            return HttpResponseRedirect('/')

        if not any(x.islower() for x in password):
            messages.error(request, 'Password must contain at least one small letter.')
            return HttpResponseRedirect('/')

        if not any(x.isupper() for x in password):
            messages.error(request, 'Password must contain at least one capital letter.')
            return HttpResponseRedirect('/')

        else:
            usr = User.objects.create_user(username=email, email=email, password=password)
            usr.first_name = fname
            usr.last_name = lname
            usr.is_staff = True
            usr.save()

            user = Recruiter(user=usr, phone=mobile, company=cname)
            user.save()
            messages.success(request, 'Recruiter Registered successfully.')
            return HttpResponseRedirect('/')
    return render(request, 'registerRecruiter.html')


@cache_control(no_cache=True, must_revalidade=True, no_store=True)
def loginUser(request):
    if request.method == 'POST':
        username = request.POST.get('email')
        password = request.POST.get('password')
        # print(username, password)
        
        if User.objects.filter(username=username):  
            usr = authenticate(username=username, password=password)
            if usr:
                login(request, usr)
                messages.success(request, 'Login successful.')
                return HttpResponseRedirect('/')
            else:
                messages.error(request, 'Wrong username or password.')
                return HttpResponseRedirect('loginUser')
        else:
            messages.error(request, 'No user found.')
            return HttpResponseRedirect('/')

@login_required(login_url='loginUser')
@cache_control(no_cache=True, must_revalidade=True, no_store=True)
def profile(request):
    applied = 0
    appliers = []
    applied_list = []
    user_detail = None

    if Job_Seeker.objects.filter(user=request.user).exists():
        user_detail = Job_Seeker.objects.get(user=request.user)
        applied = AppliedPost.objects.filter(applied_by=user_detail).count()
        applied_list = AppliedPost.objects.filter(applied_by=user_detail)
    elif Recruiter.objects.filter(user=request.user).exists():
        user_detail = Recruiter.objects.get(user=request.user)
        appliers = AppliedPost.objects.filter(job__user=user_detail)

    return render(request, 'profile.html', {
        'userDetail': user_detail,
        'applied': applied,
        'applied_to': applied_list,
        'appliers': appliers
    })

@cache_control(no_cache=True, must_revalidade=True, no_store=True)
def logoutuser(request):
    logout(request)
    messages.success(request, 'Logged out successfully.')
    return HttpResponseRedirect('/')

def apply(request, job_id):
    post = get_object_or_404(Job_Post, id=job_id)
    applier = get_object_or_404(Job_Seeker, user=request.user)

    if request.method == 'POST':
        uploaded_file = request.FILES.get('resume')
        AppliedPost.objects.create(applied_by=applier, job=post, file=uploaded_file)
        messages.success(request, 'Congrats, applied successfully.')
        return redirect('/')
    else:
        return HttpResponseRedirect('/')

@login_required(login_url='loginUser')
def addPost(request):
    if request.method == 'POST':
        user = Recruiter.objects.get(user=request.user)
        post = request.POST.get('post')
        salary = int(request.POST.get('salary'))
        description = request.POST.get('description')
        posted_on = datetime.now()
        upto = request.POST.get('upto')

        job_obj = Job_Post(user=user, post=post, salary=salary, description=description, posted_on=posted_on, upto=upto)
        job_obj.save()
        messages.success(request, 'Posted Successfully.')
        return HttpResponseRedirect('/')

def feedback(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        feedback = request.POST.get('feedback')

        feedback_obj = Feedback(name=name, email=email, feedback=feedback)
        feedback_obj.save()
        messages.success(request, 'Thanks for feedback !')
        return HttpResponseRedirect('/')

def about(request):
    return render(request, 'aboutus.html')

def searched(request):
    feeds = Feedback.objects.all()
    today = datetime.now().strftime("%Y-%m-%d")

    if request.method == 'POST':
        searchType = request.POST.get('query')

        matched = list()
        for i in Job_Post.objects.all():
            if (str(searchType).lower()) in str(i.post).lower():
                matched.append(i)
        if len(matched) == 0:
            
            messages.error(request, 'No job till now.')
            return HttpResponseRedirect('/')
        else:
            return render(request, 'home.html', {'jobs' : matched, 'feedbacks' : feeds, 'today' : today})
        
